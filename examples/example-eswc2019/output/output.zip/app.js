const db = require('sqlite');
const express = require('express');
const graphqlHTTP = require('express-graphql');
const Promise = require('bluebird');
const uuid = require('uuid');

var { buildSchema } = require('graphql');

var schema = buildSchema(`
	type Query {
		SocialMediaPosting(identifier:String,comment:String,date:String): [SocialMediaPosting]
		SocialMediaAccount(identifier:String,username:String,accountType:String): [SocialMediaAccount]
		Person(identifier:String,name:String,email:String): [Person]
	}

	type Mutation {
		createSocialMediaPosting(comment:String,date:String): SocialMediaPosting
		createSocialMediaAccount(username:String,accountType:String): SocialMediaAccount
		createPerson(email:String): Person
	}

	type SocialMediaPosting {
		identifier:String
		comment:String
		date:String
	}

	type SocialMediaAccount {
		identifier:String
		username:String
		accountType:String
	}

	type Person {
		identifier:String
		name:String
		email:String
	}

`);
class SocialMediaPosting {
}
class SocialMediaAccount {
}
class Person {
}

var root = { 
	SocialMediaPosting: function({identifier,comment,date}) {
		let sqlSelectFrom = `SELECT 'http://ex.org/Comment/' || id || '' AS tmc1c79c44,comment AS comment,date AS date FROM comments`
		let sqlWhere = []
		if(identifier != null) { sqlWhere.push("tmc1c79c44 = '"+ identifier +"'") }
		if(comment != null) { sqlWhere.push("comment = '"+ comment +"'") }
		if(date != null) { sqlWhere.push("date = '"+ date +"'") }
		let sql = "";
		if(sqlWhere.length == 0) { sql = sqlSelectFrom} else { sql = sqlSelectFrom + " WHERE " + sqlWhere.join("AND") }
		let data = db.all(sql);
		console.log(`sql = ${sql}`)
		let allInstances = [];
		return data.then(rows => {
			rows.forEach((row) => {
				let instance = new SocialMediaPosting();
				instance.identifier = `${row["tmc1c79c44"]}`
				instance.comment = row["comment"];
				instance.date = row["date"];
				allInstances.push(instance);
			})
			return allInstances;
		});
	}
,
	SocialMediaAccount: function({identifier,username,accountType}) {
		let sqlSelectFrom = `SELECT 'http://ex.org/Account/' || id || '' AS tme241ac22,username AS username,account_type AS account_type FROM accounts`
		let sqlWhere = []
		if(identifier != null) { sqlWhere.push("tme241ac22 = '"+ identifier +"'") }
		if(username != null) { sqlWhere.push("username = '"+ username +"'") }
		if(accountType != null) { sqlWhere.push("account_type = '"+ accountType +"'") }
		let sql = "";
		if(sqlWhere.length == 0) { sql = sqlSelectFrom} else { sql = sqlSelectFrom + " WHERE " + sqlWhere.join("AND") }
		let data = db.all(sql);
		console.log(`sql = ${sql}`)
		let allInstances = [];
		return data.then(rows => {
			rows.forEach((row) => {
				let instance = new SocialMediaAccount();
				instance.identifier = `${row["tme241ac22"]}`
				instance.username = row["username"];
				instance.accountType = row["account_type"];
				allInstances.push(instance);
			})
			return allInstances;
		});
	}
,
	Person: function({identifier,name,email}) {
		let sqlSelectFrom = `SELECT 'http://ex.org/Person/' || id || '' AS tm2b3b3c0b,'' || fname || ' ' || lname || '' AS tm9934b74f,email AS email FROM authors`
		let sqlWhere = []
		if(identifier != null) { sqlWhere.push("tm2b3b3c0b = '"+ identifier +"'") }
		if(name != null) { sqlWhere.push("tm9934b74f = '"+ name +"'") }
		if(email != null) { sqlWhere.push("email = '"+ email +"'") }
		let sql = "";
		if(sqlWhere.length == 0) { sql = sqlSelectFrom} else { sql = sqlSelectFrom + " WHERE " + sqlWhere.join("AND") }
		let data = db.all(sql);
		console.log(`sql = ${sql}`)
		let allInstances = [];
		return data.then(rows => {
			rows.forEach((row) => {
				let instance = new Person();
				instance.identifier = `${row["tm2b3b3c0b"]}`
				instance.name = `${row["tm9934b74f"]}`
				instance.email = row["email"];
				allInstances.push(instance);
			})
			return allInstances;
		});
	}
	,
	createSocialMediaPosting: function({comment,date}) {
		if(identifier == undefined) { identifier = uuid.v4().substring(0,8) }
		if(comment == undefined) { comment = 'NULL'}	
		if(date == undefined) { date = 'NULL'}	
		let sqlInsert = `INSERT INTO comments(comment,date) VALUES('${comment}','${date}')`
		let status = db.run(sqlInsert).then(dbStatus => { return dbStatus });
		console.log(`sql = ${sqlInsert}`)
		let newInstance = new SocialMediaPosting()
		newInstance.comment = comment
		newInstance.date = date
		return newInstance
	}
,
	createSocialMediaAccount: function({username,accountType}) {
		if(identifier == undefined) { identifier = uuid.v4().substring(0,8) }
		if(username == undefined) { username = 'NULL'}	
		if(accountType == undefined) { accountType = 'NULL'}	
		let sqlInsert = `INSERT INTO accounts(username,account_type) VALUES('${username}','${accountType}')`
		let status = db.run(sqlInsert).then(dbStatus => { return dbStatus });
		console.log(`sql = ${sqlInsert}`)
		let newInstance = new SocialMediaAccount()
		newInstance.username = username
		newInstance.accountType = accountType
		return newInstance
	}
,
	createPerson: function({email}) {
		if(identifier == undefined) { identifier = uuid.v4().substring(0,8) }
		if(email == undefined) { email = 'NULL'}	
		let sqlInsert = `INSERT INTO authors(email) VALUES('${email}')`
		let status = db.run(sqlInsert).then(dbStatus => { return dbStatus });
		console.log(`sql = ${sqlInsert}`)
		let newInstance = new Person()
		newInstance.email = email
		return newInstance
	}

};
const app = express();
const port = process.env.PORT || 4321;
app.use('/graphql', graphqlHTTP({schema: schema,  rootValue: root,  graphiql: true,}));
Promise.resolve().then(() => db.open('eswc2019example.sqlite', { Promise }))
	.catch(err => console.error(err.stack))
	.finally(() => app.listen(port));

console.log('Running a GraphQL API server at localhost:4321/graphql');
