import {GraphQLObjectType,GraphQLList,GraphQLNonNull,GraphQLString,GraphQLInt,GraphQLFloat} from 'graphql'
import knex from './database'
const SocialMediaPosting = new GraphQLObjectType({	description: 'An instance of SocialMediaPosting',
	name: 'SocialMediaPosting',
	sqlTable: 'comments',
	uniqueKey: 'id',
	fields: () => ({
		identifier:{
			type: GraphQLString,
			sqlDeps: ['id'],
		sqlExpr: table => `'http://ex.org/Comment/' || ${table}.id || ''`
		},
		comment:{
			type: GraphQLString,
			sqlColumn: 'comment'
		},
		date:{
			type: GraphQLString,
			sqlColumn: 'date'
		},
		author:{
			type: Person,
			args: {
				identifier:{type:GraphQLString},
				name:{type:GraphQLString},
				email:{type:GraphQLString}
			},
			where: (table, args, context) => {
				let sqlWhere = []
				if(args.identifier != null) { sqlWhere.push(`'http://ex.org/Person/' || ${table}.id || '' = '${args.identifier}'`) }
				if(args.name != null) { sqlWhere.push(`'' || ${table}.fname || ' ' || ${table}.lname || '' = '${args.name}'`) }
				if(args.email != null) { sqlWhere.push(`${table}.email = '${args.email}'`) }
				let sqlWhereString = sqlWhere.join(" AND ")
				console.log(`sqlWhereString = ${sqlWhereString}`)
				return sqlWhereString
			},
			sqlJoin: (child, parent) => `${child}.author = ${parent}.id`
		}
	})
})
export default SocialMediaPosting
import Person from './Person'